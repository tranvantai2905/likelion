let draggedItem = null;

document.addEventListener('dragstart', (event) => {
    if (event.target.classList.contains('item')) {
        draggedItem = event.target;
        setTimeout(() => {
            event.target.style.opacity = '0.5';
        }, 0);
    }
});

document.addEventListener('dragend', (event) => {
    if (event.target.classList.contains('item')) {
        setTimeout(() => {
            event.target.style.opacity = '1';
            draggedItem = null;
        }, 0);
    }
});

document.addEventListener('dragover', (event) => {
    event.preventDefault();
});

document.addEventListener('dragenter', (event) => {
    if (event.target.classList.contains('item')) {
        event.target.style.border = '2px dashed #000';
    }
});

document.addEventListener('dragleave', (event) => {
    if (event.target.classList.contains('item')) {
        event.target.style.border = 'none';
    }
});

document.addEventListener('drop', (event) => {
    if (event.target.classList.contains('item') && draggedItem) {
        event.preventDefault();
        
        // Swap the positions of the dragged item and the drop target
        let target = event.target;
        let parent = target.parentNode;
        let draggedIndex = Array.from(parent.children).indexOf(draggedItem);
        let targetIndex = Array.from(parent.children).indexOf(target);

        if (draggedIndex < targetIndex) {
            parent.insertBefore(target, draggedItem);
        } else {
            parent.insertBefore(draggedItem, target);
        }

        event.target.style.border = 'none';
    }
});
